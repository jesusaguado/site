% Problema 1.12

% Aproximando pi de dos maneras distintas
clear
clc

N = input("N: ")

a = zeros(1,N);
b = zeros(1,N);
aprox_a = zeros(1,N);
aprox_b = zeros(1,N);
a(1) = 1;
aprox_a(1) = a(1)*2;
b(1) = 1;
aprox_b(1) = b(1)*2;
for i=2:N
  a(i) = (sqrt(1+ a(i-1)^2) - 1) / a(i-1);
  aprox_a(i) = a(i)*2^(i+1);
  b(i) = b(i-1) / (sqrt(1 + b(i-1)^2) + 1);
  aprox_b(i) = b(i)*2^(i+1);
end

aprox_a
aprox_b

% Para N = 26, el primer método empieza a separarse de pi, por acumulaciones
% de error máquina. Esto pasa porque a_n empieza a ser muy pequeño y se está
% dividiendo por a_n en la primera expresión


