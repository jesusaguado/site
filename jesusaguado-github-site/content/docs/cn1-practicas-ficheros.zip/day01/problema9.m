function M = problema9 (n1, n2)
M = [ ];
while n1 >= 4 && n2 >=2

  % genero el dado atacante con números aleatorios
  dados_atacante = ceil(rand(1,min(3,n1))*6);
  dados_defensor = ceil(rand(1,min(2,n2))*6);

  % ordeno los resultados de mayor a menor
  dados_atacante = sort(dados_atacante,"descend")
  dados_defensor = sort(dados_defensor, "descend")

  if length(dados_defensor) == 1
    dados_defensor = [dados_defensor, dados_defensor]
  end

  if length(dados_atacante) == 1
    dados_atacante = [dados_atacante, dados_atacante]
  end

  % ejecuto las comparaciones
  for i = 1:2
    if dados_atacante(i) > dados_defensor(i)
      n2 = n2 - 1;
      disp("Defensor pierde 1 ejército")
    else
      n1 = n1 -1;
      disp("Atacante pierde 1 ejército")
    end
  end

  M = [M;n1, n2];
end % fin del bucle while


end
