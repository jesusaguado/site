% Problema 1.6
% Representar la superficie z = (1-y^2) * sin(x)
% en x en [-pi,pi], y en [-1,1]

% Tenemos que generar un mallado BIDIMENSIONAL
% esto se puede hacer a partir de dos mallados unidimensionales
% con mesh(xs, ys)

xs = linspace(-pi,pi,100);
ys = linspace(-1, 1, 100);

[xx yy] = meshgrid(xs,ys);


zz = (1-yy.^2).*sin(xx);

surf(xx,yy,zz)
hold on
xlabel('Eje X')
ylabel('Eje Y')
hold off
