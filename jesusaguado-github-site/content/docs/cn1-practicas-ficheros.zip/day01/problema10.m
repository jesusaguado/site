% Problema 1.10

% Realiza las siguientes operaciones: (1+eps)-1; (10+eps)-10; (0.1+eps)-0.1.
% ¿Qué ocurre? ¿Por qué?
% Operar (a + b ∗ eps) − a para distintos valores a y b
% Explicar el error relativo



disp("(1 + eps) -1")
(1+eps)-1
disp("(10 + eps) -10")
(10+eps)-10
disp("(0.1 + eps) - 0.1")
(0.1 + eps) - 0.1


% Lo que ocurre es que en números de coma flotante, no hay ninguno entre
% 10 y 10 + eps (el error máquina es relativo!)
