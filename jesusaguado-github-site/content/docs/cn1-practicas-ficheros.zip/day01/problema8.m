%Problema (1.8)
% Crear un script para simular un lanzamiento de dados para el juego RISK.
%  - El atacante lanza tres dados por 3 ejercitos.
%  - La defensa lanza dos dados por dos ejercitos.
%  - Se compara los dos mejores resultados del atacante con la defensa.
%  - Si el mejor resultado es mayor que el mejor del defensa, la defensa
% pierde un ejercito. Si es el caso contrario, lo pierde el atacante.
%  - Idem, con el segundo par de comparación.
%  - Se para el ataque si los atacantes tienen menos de 4 ejercitos y la
% defensa menos de 2 ejercitos.

clear all
clc

atacante = 3
defensor = 2

while atacante >= 1 && defensor >=2

  % tiro los dados con números aleatorios (rand entre 0 y 1, re-escalo *6, y redondeo hacia arriba)

  dados_atacante = ceil(rand(1,min(3,atacante))*6);
  dados_defensor = ceil(rand(1,min(2,defensor))*6);

  % ordeno los resultados de mayor a menor
  dados_atacante = sort(dados_atacante,"descend")
  dados_defensor = sort(dados_defensor, "descend")

  if length(dados_defensor) == 1
    dados_defensor = [dados_defensor, dados_defensor]
  end

  if length(dados_atacante) == 1
    dados_atacante = [dados_atacante, dados_atacante]
  end

  % ejecuto las comparaciones
  for i = 1:2
    if dados_atacante(i) > dados_defensor(i)
      defensor = defensor - 1;
      disp("Defensor pierde 1 ejército")
    else
      atacante = atacante -1;
      disp("Atacante pierde 1 ejército")
    end
  end

  [atacante, defensor]
  end
