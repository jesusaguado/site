% Problema 11

% Sean los polinomios
% y = (x − 1)5,
% Y = x5 − 5x4 + 10x3 − 10x2 + 5x − 1.
% Representar en dos figuras estas dos funciones en el intervalo
% (0.99999, 1.0001) con al menos 100 puntos. ¿Qué sucede? ¿Por qué?

clear all
close all

xs = linspace(0.99999, 1.0001, 100)

ys1 = (xs-1).^5
ys2 = xs.^5 - 5*xs.^4 + 10*xs.^3 - 10*xs.^2 + 5*xs - 1

plot(xs, ys1,'r')
hold on
plot(xs, ys2,'b')
hold off

% La segunda representación del polinomio involucra muchas más operaciones
% y el error de redondeo por coma flotante se acumula y propaga!


