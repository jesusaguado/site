%% Problema 1.5

% representar graficamente en [0,2pi] las funciones
% y1(x) = sin(x)
% y2(x) = sin(x) / 1 + x


clear
clc

% Creo un vector de mallado del intervalo [0,2pi]
xs = linspace(0,2*pi,100);

% Y calculo la imagen a través de la función de ese vector
% para cada una de las dos funciones

ys1 = sin(xs);

ys2 = sin(xs)./(1+xs);


plot(xs,ys1,'r','LineWidth',3)
axis([0 2*pi -2 2])
hold on
plot(xs,ys2,'--b','LineWidth',1.5)
xlabel('Eje X')
legend('ys_1','ys_2')
ylabel('Eje Y')
hold off
gca
