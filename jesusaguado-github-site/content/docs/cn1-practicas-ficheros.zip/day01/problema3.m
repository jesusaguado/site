% Problema 1.3: Escribir y operar con las matrices
% A = ( 1  0  1 )
%     ( 2 -1  1 )
%
% B = (-2  1  0 )
%     ( 3  1  1 )

clear
clc

% Declaramos las matrices
A = [1, 0, 1; 2, -1, 2];

B = [-2, 1, 0; 3, 1, 1];

% Podemos pedirle a Matlab sus tamaños
size(A)

size(B)

% Podemos sumarlas
disp('A + B')
A + B

% Podemos restarlas
disp('A - B')
A - B

% Pero no podemos multiplicarlas!
%A*B

% Sí podemos multiplicarlas elemento a elemento, porque son
% del mismo tamaño

disp('A .* B')
A.*B

% Podemos calcular traspuestas
C = A*B'

% Y para las cuadradas podemos calcular inversa y determinante
det(C)
inv(C)

% Podemos incluso definir matrices de números complejos
Z = [1+3i, -8i; 3, 0.5 + 0.3i]
det(Z)
