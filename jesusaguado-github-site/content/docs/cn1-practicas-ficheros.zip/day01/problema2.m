% Problema 1.2
% Aplicar Pitágoras y cosh^2 - sinh^2
% a diferentes valores reales en un script


% Pitágoras: necesitos unos valores para un cateto (a) y el otro (b)
%   Queremos calcular c = sqrt(a^2 + b^2) para cada para

as = [2,3,8]
bs = [3,4,7]

% Utilizamos la notación de ".", aplicar operación a vectores
%   elemento a elemento.

cs = sqrt(as.^2 + bs.^2)


% Seno y coseno hiperbólicos
% Podemos generar un vector de números aleatorios

v = rand(10,1)

y = cosh(v).^2 - sinh(v).^2



