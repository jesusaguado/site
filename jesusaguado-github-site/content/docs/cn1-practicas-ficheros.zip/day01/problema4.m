% Problema 1.4
% Escribir en un script una matriz de tamaño n con
% -2 en la diagonal y 1 en la diagonal superior e inferiorto

%% Método 1: con los comandos diag

clc
clear all
n = 6

% Creo un vector fila de -2's (n de ellos)
v = ones(1,n) * (-2)
% Y un vector fila de 1's (n-1 de ellos)
w = ones(1,n-1)
% Y creo mi matriz sumando matrices diagonales / supra /infra diagonales

A1 = diag(v)
A2 = diag(w,-1)
A3 = diag(w,+1)
A = A1 + A2 + A3


%% Método 2: con dos bucles for, iterando en todas
% las entradas de la matriz

% Inicializ la matriz con 0's en todas partes, de
% tamaño n x n
B = zeros(n,n)

for i=1:n
  for j=1:n
    if i == j % si el par de indices es de la diagonal
      B(i,j) = -2;
     elseif abs(i-j) == 1 % si el par de indices es de la supra/infra diagonal
      B(i,j) = 1;
      end
end
end
B
