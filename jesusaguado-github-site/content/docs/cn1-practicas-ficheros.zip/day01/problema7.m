% Problema 1.7

% Hacer un script que nos solicite un número natural n y nos entregue el
% n-ésimo término de sucesión de Fibonacci: Fn+1 = Fn + Fn−1, F0 = 0,

clear
clc

n = input('Introducir índice a buscar en la sucesión de Fibonacci: ');

% inicializo un vector de n elementos (nulos de momento)
a = zeros(1,n);

% Construyo la sucesión de Fibonacci sobre ese vector

% Primero el caso base...
a(1) = 1;
a(2) = 1;

% Y luego la relación de recurrencia con un bucle for

for j=3:n
  a(j) = a(j-1) + a(j-2);
end

a(n)


